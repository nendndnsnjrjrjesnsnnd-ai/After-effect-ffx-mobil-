package com.ffxeditor;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    WebView w;
    ValueCallback<Uri[]> cb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface public void save(String name, String b64) {
                try {
                    byte[] d = Base64.decode(b64, Base64.DEFAULT);
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    OutputStream o = getContentResolver().openOutputStream(u);
                    o.write(d); o.close();
                    toast("Kaydedildi: İndirilenler/" + name);
                } catch (Exception e) { toast("Kaydedilemedi: " + e.getMessage()); }
            }
        }, "Android");
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> c, FileChooserParams p) {
                if (cb != null) cb.onReceiveValue(null);
                cb = c;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 1);
                return true;
            }
        });
        w.loadUrl("file:///android_asset/index.html");
    }

    void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int r, int res, Intent d) {
        super.onActivityResult(r, res, d);
        if (cb != null) {
            cb.onReceiveValue(res == RESULT_OK && d != null && d.getData() != null ? new Uri[]{d.getData()} : null);
            cb = null;
        }
    }
}
